interface CreateAddressDTO {
  userId: string;
  street: string;
  city: string;
}
