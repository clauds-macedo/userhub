interface UpdateAddressDTO {
  street?: string;
  city?: string;
}
